// ----- Modal wiring -----
function openModal(agent){
  const modal = document.getElementById(agent + 'Modal');
  if(!modal) return;
  modal.style.display = 'block';
  // ensure canvas is visible before init
  setTimeout(() => initializeCharts(agent), 60);
}
function closeModalById(id){
  const el = document.getElementById(id);
  if(el) el.style.display = 'none';
}

document.addEventListener('click', (e)=>{
  const btnAgent  = e.target.closest('.expand-btn')?.dataset.agent;
  const cardAgent = e.target.closest('.agent-card')?.dataset.agent;

  if(btnAgent){ e.stopPropagation(); openModal(btnAgent); }
  else if(cardAgent){ openModal(cardAgent); }

  if (e.target.classList && e.target.classList.contains('modal')) { e.target.style.display='none'; }
  const closeId = e.target.dataset?.close; if(closeId){ closeModalById(closeId); }
});

document.addEventListener('keydown', (e)=>{
  if(e.key === 'Escape'){
    document.querySelectorAll('.modal').forEach(m => m.style.display='none');
  }
});

// ----- Chart.js defaults (keep your colors) -----
Chart.defaults.color = '#e6edf6';
Chart.defaults.borderColor = 'rgba(139,152,182,.25)';

// ----- Chart initializers -----
function initializeCharts(agent){
  switch(agent){
    case 'marketing': initMarketingCharts(); break;
    case 'finance':   initFinanceCharts();   break;
    case 'legal':     initLegalCharts();     break;
    case 'social':    initSocialCharts();    break;
    case 'operations':initOperationsCharts();break;
  }
}

function initMarketingCharts(){
  const months = ['Jan','Feb','Mar','Apr','May','Jun'];
  new Chart(document.getElementById('marketingLeadsChart'),{
    type:'line',
    data:{labels:months, datasets:[{label:'New Leads', data:[1200,1450,1800,2100,2400,2847],
      borderColor:'#b45309', backgroundColor:'rgba(180,83,9,.14)', tension:.35, fill:true}]},
    options:{plugins:{legend:{display:false}}}
  });
  new Chart(document.getElementById('marketingChannelsChart'),{
    type:'doughnut',
    data:{labels:['Google Ads','Facebook','LinkedIn','Organic'],
      datasets:[{data:[35,28,22,15], backgroundColor:['#2563eb','#1877f2','#0077b5','#0ea5a5']}]},
    options:{plugins:{legend:{position:'bottom'}}}
  });
  new Chart(document.getElementById('marketingConversionChart'),{
    type:'bar',
    data:{labels:['Google','Facebook','LinkedIn','Email'],
      datasets:[{label:'Conversion Rate (%)', data:[12.5,8.3,15.7,22.1], backgroundColor:'#b45309'}]},
    options:{plugins:{legend:{display:false}}}
  });
  new Chart(document.getElementById('marketingCACChart'),{
    type:'line',
    data:{labels:months, datasets:[{label:'CAC ($)', data:[180,165,142,138,125,119],
      borderColor:'#b91c1c', backgroundColor:'rgba(185,28,28,.14)', tension:.35, fill:true}]},
    options:{plugins:{legend:{display:false}}}
  });
}

function initFinanceCharts(){
  const months = ['Jan','Feb','Mar','Apr','May','Jun'];
  new Chart(document.getElementById('financeCashflowChart'),{
    type:'line',
    data:{labels:months, datasets:[{label:'Cashflow ($)', data:[32000,38000,41000,39000,45000,48000],
      borderColor:'#0ea5a5', backgroundColor:'rgba(14,165,165,.14)', tension:.35, fill:true}]},
    options:{plugins:{legend:{display:false}}}
  });
  new Chart(document.getElementById('financeExpensesChart'),{
    type:'doughnut',
    data:{labels:['Payroll','Marketing','Ops','Office','Other'],
      datasets:[{data:[45,25,15,10,5], backgroundColor:['#2563eb','#b45309','#b91c1c','#4f46e5','#0ea5a5']}]},
    options:{plugins:{legend:{position:'bottom'}}}
  });
  new Chart(document.getElementById('financeRevenueChart'),{
    type:'bar',
    data:{labels:months, datasets:[
      {label:'Revenue', data:[220000,245000,268000,275000,287000,295000], backgroundColor:'#0ea5a5'},
      {label:'Expenses', data:[180000,185000,195000,205000,215000,224000], backgroundColor:'#b91c1c'}
    ]},
    options:{plugins:{legend:{position:'bottom'}}}
  });
  new Chart(document.getElementById('financeForecastChart'),{
    type:'line',
    data:{labels:['Jul','Aug','Sep'], datasets:[{label:'Profit Forecast ($)', data:[175000,185000,195000],
      borderColor:'#4f46e5', backgroundColor:'rgba(79,70,229,.14)', borderDash:[5,5], tension:.35, fill:true}]},
    options:{plugins:{legend:{display:false}}}
  });
}

function initLegalCharts(){
  new Chart(document.getElementById('legalContractsChart'),{
    type:'doughnut',
    data:{labels:['Active','Pending','Expired','Under Review'],
      datasets:[{data:[23,5,3,2], backgroundColor:['#0ea5a5','#b45309','#b91c1c','#4f46e5']}]},
    options:{plugins:{legend:{position:'bottom'}}}
  });
  new Chart(document.getElementById('legalComplianceChart'),{
    type:'line',
    data:{labels:['Jan','Feb','Mar','Apr','May','Jun'],
      datasets:[{label:'Compliance Alerts', data:[12,8,5,3,7,4],
        borderColor:'#b91c1c', backgroundColor:'rgba(185,28,28,.14)', tension:.35, fill:true}]},
    options:{plugins:{legend:{display:false}}}
  });
  new Chart(document.getElementById('legalExpirationChart'),{
    type:'bar',
    data:{labels:['This week','This month','3 months','6 months'],
      datasets:[{label:'Expiring', data:[2,3,8,12], backgroundColor:['#b91c1c','#b45309','#2563eb','#0ea5a5']}]},
    options:{plugins:{legend:{display:false}}}
  });
  new Chart(document.getElementById('legalCostsChart'),{
    type:'doughnut',
    data:{labels:['Contracts','Advisory','Litigation','Licensing'],
      datasets:[{data:[40,30,20,10], backgroundColor:['#4f46e5','#2563eb','#b91c1c','#0ea5a5']}]},
    options:{plugins:{legend:{position:'bottom'}}}
  });
}

function initSocialCharts(){
  new Chart(document.getElementById('socialEngagementChart'),{
    type:'bar',
    data:{labels:['Instagram','Facebook','LinkedIn','TikTok','YouTube'],
      datasets:[{label:'Engagement (%)', data:[12.3,8.7,6.2,15.8,4.1],
        backgroundColor:['#e1306c','#1877f2','#0077b5','#000000','#ff0000']}]},
    options:{plugins:{legend:{display:false}}}
  });
  new Chart(document.getElementById('socialFollowersChart'),{
    type:'line',
    data:{labels:['Jan','Feb','Mar','Apr','May','Jun'],
      datasets:[{label:'Followers', data:[38500,41200,43800,45100,46585,47832],
        borderColor:'#b91c1c', backgroundColor:'rgba(185,28,28,.14)', tension:.35, fill:true}]},
    options:{plugins:{legend:{display:false}}}
  });
  new Chart(document.getElementById('socialContentChart'),{
    type:'doughnut',
    data:{labels:['Images','Video','Stories','Text'],
      datasets:[{data:[35,40,20,5], backgroundColor:['#2563eb','#b91c1c','#b45309','#0ea5a5']}]},
    options:{plugins:{legend:{position:'bottom'}}}
  });
  new Chart(document.getElementById('socialTimingChart'),{
    type:'bar',
    data:{labels:['6–9','9–12','12–15','15–18','18–21','21–24'],
      datasets:[{label:'Engagement (%)', data:[5.2,8.7,12.3,15.8,18.2,9.1], backgroundColor:'#b91c1c'}]},
    options:{plugins:{legend:{display:false}}}
  });
}

function initOperationsCharts(){
  new Chart(document.getElementById('operationsEfficiencyChart'),{
    type:'radar',
    data:{labels:['Sales','Marketing','Support','Engineering','Finance'],
      datasets:[{label:'Efficiency (%)', data:[92,88,96,89,94],
        borderColor:'#2563eb', backgroundColor:'rgba(37,99,235,.20)'}]},
    options:{plugins:{legend:{display:false}}}
  });
  new Chart(document.getElementById('operationsResponseChart'),{
    type:'line',
    data:{labels:['Jan','Feb','Mar','Apr','May','Jun'],
      datasets:[{label:'Response Time (h)', data:[4.2,3.8,3.1,2.9,2.5,2.3],
        borderColor:'#0ea5a5', backgroundColor:'rgba(14,165,165,.14)', tension:.35, fill:true}]},
    options:{plugins:{legend:{display:false}}}
  });
  new Chart(document.getElementById('operationsTasksChart'),{
    type:'doughnut',
    data:{labels:['Completed','In Progress','Queued','Urgent'],
      datasets:[{data:[47,12,8,3], backgroundColor:['#22c55e','#b45309','#2563eb','#b91c1c']}]},
    options:{plugins:{legend:{position:'bottom'}}}
  });
  new Chart(document.getElementById('operationsResourcesChart'),{
    type:'bar',
    data:{labels:['Servers','Licenses','Headcount','Budget'],
      datasets:[{label:'Utilization (%)', data:[78,92,85,73],
        backgroundColor:['#2563eb','#0ea5a5','#b45309','#4f46e5']}]},
    options:{plugins:{legend:{display:false}}}
  });
}

// entry animation (optional)
document.addEventListener('DOMContentLoaded', ()=>{
  document.querySelectorAll('.agent-card').forEach((card, i)=>{
    card.style.opacity = '0'; card.style.transform = 'translateY(16px)';
    setTimeout(()=>{ card.style.transition='all .5s ease'; card.style.opacity='1'; card.style.transform='translateY(0)'; }, i*90);
  });
});
