// Live "Last update" clock
const last = document.getElementById('lastUpdated');
function stamp(){ if(last) last.textContent = new Date().toLocaleString(); }
stamp(); setInterval(stamp, 1000);

const q = document.getElementById('q');
const refreshBtn = document.getElementById('refreshBtn');
const shortcutsBtn = document.getElementById('shortcutsBtn');

window.addEventListener('keydown', (e)=>{
  if (e.key === '/' && document.activeElement !== q){ e.preventDefault(); q?.focus(); }
  else if ((e.key === 'r' || e.key === 'R') && !e.metaKey && !e.ctrlKey){ e.preventDefault(); simulateRefresh(); }
  else if (e.key === '?'){ e.preventDefault(); showShortcuts(); }
  else if (e.key.toLowerCase() === 'a' && !e.ctrlKey && !e.metaKey){ window.location.href = 'index.html'; }
});

refreshBtn?.addEventListener('click', simulateRefresh);
shortcutsBtn?.addEventListener('click', (e)=>{ e.preventDefault(); showShortcuts(); });

function simulateRefresh(){
  document.querySelectorAll('.kpi').forEach(k=>{
    k.style.transition='background .4s';
    k.style.background='linear-gradient(90deg, rgba(255,255,255,.06), rgba(255,255,255,.12), rgba(255,255,255,.06))';
    k.style.backgroundSize='200% 100%';
    k.animate([{backgroundPosition:'0% 0%'},{backgroundPosition:'200% 0%'}],{duration:900,iterations:1});
    setTimeout(()=>k.style.background='rgba(255,255,255,.03)', 920);
  });
  stamp();
}

function showShortcuts(){
  alert('Keyboard shortcuts:\n\n/  Focus quick search\nR  Refresh KPIs\n?  This help\nA  Go to Agents');
}
// דוגמה בתוך handler קיים
if (window.Ticker && typeof window.Ticker.push === 'function') {
  window.Ticker.push('social', 'Uploaded Instagram story');
  // אפשר: 'legal' | 'finance' | 'marketing' | 'social'
}
