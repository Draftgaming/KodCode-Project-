// ticker.js — shared bottom ticker (injects itself, persists to localStorage)
(() => {
  const STORAGE_KEY = 'ticker_items';
  const MAX_ITEMS = 120;

  const AGENTS = {
    legal:     { label: 'Legal',     icon: '⚖️' },
    finance:   { label: 'Finance',   icon: '💸' },
    marketing: { label: 'Marketing', icon: '🎯' },
    social:    { label: 'Social',    icon: '📱' },
  };

  let trackEl = null;

  function load(){
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
    catch { return []; }
  }
  function save(items){
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items.slice(-MAX_ITEMS)));
  }

  function ensureDom(){
    if (document.querySelector('.ticker')) return;
    const wrap = document.createElement('div');
    wrap.className = 'ticker';
    wrap.setAttribute('role', 'region');
    wrap.setAttribute('aria-label', 'Live ticker');
    trackEl = document.createElement('div');
    trackEl.className = 'ticker-track';
    trackEl.id = 'tickerTrack';
    wrap.appendChild(trackEl);
    document.body.appendChild(wrap);
  }

  function buildLine(items){
    if (!items.length) return '';
    const html = items.map(it => {
      const a = AGENTS[it.agentKey] || { label: it.agentKey, icon: '🟢' };
      return `<span class="ticker-item"><span class="pill ${it.agentKey}">${a.icon} ${a.label}</span>${it.text}</span>`;
    }).join('<span class="ticker-item">•</span>');
    // duplicate for smooth loop
    return html + html;
  }

  function render(){
    if (!trackEl) trackEl = document.getElementById('tickerTrack');
    if (!trackEl) return;
    const items = load();
    // show last 20
    trackEl.innerHTML = buildLine(items.slice(-20));
  }

  function push(agentKey, text){
    const items = load();
    items.push({ agentKey, text, ts: Date.now() });
    save(items);
    render();
  }

  document.addEventListener('DOMContentLoaded', () => {
    ensureDom();
    // seed minimal examples if empty (so it doesn’t look broken)
    if (load().length === 0) {
      save([
        {agentKey:'marketing', text:'Uploaded Instagram story', ts: Date.now()-60000},
        {agentKey:'finance',   text:'Updated MTD revenue snapshot', ts: Date.now()-50000},
        {agentKey:'legal',     text:'Reviewed vendor contract', ts: Date.now()-40000},
        {agentKey:'social',    text:'Replied to 5 mentions', ts: Date.now()-30000},
      ]);
    }
    render();
  });

  // Expose a tiny API for other pages to publish items
  window.Ticker = { push };
})();
