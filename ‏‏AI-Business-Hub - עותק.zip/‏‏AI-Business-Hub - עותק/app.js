document.addEventListener('DOMContentLoaded', () => {
  const botFab     = document.getElementById('botFab');
  const chatPanel  = document.getElementById('chatPanel');
  const closeChat  = document.getElementById('closeChat');
  const sendMsg    = document.getElementById('sendMsg');
  const userInput  = document.getElementById('userMsg');
  const chatBody   = document.querySelector('.chat-body');

  // פתיחה רק בלחיצה על האייקון
  botFab.addEventListener('click', (e) => {
    e.preventDefault();
    chatPanel.hidden = false;
    userInput.focus();
  });

  // סגירה עם X
  closeChat.addEventListener('click', () => {
    chatPanel.hidden = true;
  });

  // סגירה בלחיצה מחוץ לחלון
  document.addEventListener('click', (e) => {
    if (!chatPanel.hidden && !chatPanel.contains(e.target) && !botFab.contains(e.target)) {
      chatPanel.hidden = true;
    }
  });

  // סגירה עם Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') chatPanel.hidden = true;
  });

  // שליחת הודעה
  sendMsg.addEventListener('click', () => send());
  userInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });

  function send(){
    const msg = userInput.value.trim();
    if(!msg) return;
    addMsg(msg, 'user-msg');
    userInput.value = '';
    setTimeout(() => addMsg('Bot: I heard you say - ' + msg, 'bot-msg'), 700);
  }
  function addMsg(text, cls){
    const p = document.createElement('p');
    p.textContent = text;
    p.className = cls;
    chatBody.appendChild(p);
    chatBody.scrollTop = chatBody.scrollHeight;
  }
});
