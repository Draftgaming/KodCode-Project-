// updates.js — live feed + bottom ticker
document.addEventListener('DOMContentLoaded', () => {
  const feed = document.getElementById('feed');
  const track = document.getElementById('tickerTrack');

  const AGENTS = [
    { key:'legal',     label:'Legal',     icon:'⚖️' },
    { key:'finance',   label:'Finance',   icon:'💸' },
    { key:'marketing', label:'Marketing', icon:'🎯' },
    { key:'social',    label:'Social',    icon:'📱' },
  ];

  // דוגמאות תוכן
  const SAMPLES = {
    legal: [
      'Reviewed 3 vendor contracts',
      'Flagged clause risk in agreement #842',
      'Auto-renewed 2 NDAs',
      'Closed 1 compliance alert'
    ],
    finance: [
      'Posted 12 invoices to ERP',
      'Reconciled 2 bank statements',
      'Updated MTD revenue snapshot',
      'Detected variance in COGS (−2.1%)'
    ],
    marketing: [
      'Launched ad set on Meta',
      'Optimized CPC for search campaign',
      'Generated 64 new leads',
      'Updated pipeline attribution model'
    ],
    social: [
      'Uploaded Instagram story',
      'Scheduled 3 posts for 20:15',
      'Replied to 7 mentions',
      'Boosted TikTok video (#431)'
    ]
  };

  const items = [];   // שמירת כל האירועים גם לטיקר

  function nowTime(){
    const d = new Date();
    const two = n => n.toString().padStart(2,'0');
    return `${two(d.getHours())}:${two(d.getMinutes())}:${two(d.getSeconds())}`;
  }

  function addItem(agentKey, text){
  const agent = AGENTS.find(a => a.key === agentKey);
  const li = document.createElement('li');
  li.className = 'feed-item';
  li.innerHTML = `
    <div class="feed-time">${nowTime()}</div>
    <div class="feed-body">
      <div class="feed-title">
        <span class="pill ${agent.key}">${agent.icon} ${agent.label}</span>
        ${text}
      </div>
      <div class="feed-meta">Recorded by ${agent.label} agent</div>
    </div>
  `;
  feed.prepend(li);

  // NEW: also publish to the global ticker
  if (window.Ticker && typeof window.Ticker.push === 'function') {
    window.Ticker.push(agentKey, text);
  }
}


  function rebuildTicker(){
    if(items.length === 0) return;
    const line = items.slice(-10).map(it =>
      `<span class="ticker-item"><span class="pill ${it.agent.key}">${it.agent.icon} ${it.agent.label}</span>${it.text}</span>`
    ).join('<span class="ticker-item">•</span>');
    // נכפיל את התוכן כדי שהאנימציה תתגלגל חלק
    track.innerHTML = line + line;
  }

  // יצירה ראשונית
  for(let i=0;i<6;i++){
    const a = AGENTS[Math.floor(Math.random()*AGENTS.length)].key;
    const t = SAMPLES[a][Math.floor(Math.random()*SAMPLES[a].length)];
    addItem(a, t);
  }

  // "חיים" — כל כמה שניות תווסף שורה חדשה (אפשר לכבות/לשנות)
  setInterval(() => {
    const a = AGENTS[Math.floor(Math.random()*AGENTS.length)].key;
    const t = SAMPLES[a][Math.floor(Math.random()*SAMPLES[a].length)];
    addItem(a, t);
  }, 5000);
});
