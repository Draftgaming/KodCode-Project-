// bot.js
document.addEventListener('DOMContentLoaded', () => {
  const fab    = document.getElementById('botFab');
  const panel  = document.getElementById('botPanel');
  const close  = panel.querySelector('.bot-close');
  const body   = document.getElementById('botBody');
  const form   = document.getElementById('botForm');
  const input  = document.getElementById('botInput');

  function openPanel(){
    panel.classList.add('is-open');
    panel.setAttribute('aria-hidden', 'false');
    fab.setAttribute('aria-expanded', 'true');
    input.focus();
  }
  function closePanel(){
    panel.classList.remove('is-open');
    panel.setAttribute('aria-hidden', 'true');
    fab.setAttribute('aria-expanded', 'false');
  }
  function togglePanel(){
    panel.classList.contains('is-open') ? closePanel() : openPanel();
  }

  fab.addEventListener('click', (e) => { e.preventDefault(); togglePanel(); });
  close.addEventListener('click', closePanel);

  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closePanel(); });
  document.addEventListener('click', (e) => {
    if (!panel.classList.contains('is-open')) return;
    if (!panel.contains(e.target) && !fab.contains(e.target)) closePanel();
  });

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = (input.value || '').trim();
    if (!text) return;

    appendMsg(text, 'you');
    input.value = '';

    setTimeout(() => appendMsg('Got it! This is a demo 🤖', 'bot'), 400);
  });

  function appendMsg(t, who){
    const row = document.createElement('div');
    row.className = 'bot-msg' + (who === 'you' ? ' bot-msg-you' : ' bot-msg-bot');
    row.textContent = t;
    body.appendChild(row);
    body.scrollTop = body.scrollHeight;
  }
});
